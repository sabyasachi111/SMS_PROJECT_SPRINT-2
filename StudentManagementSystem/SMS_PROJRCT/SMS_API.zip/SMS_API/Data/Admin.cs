﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SMS_API.Data
{
    public partial class Admin
    {
        public decimal AdminId { get; set; }
        public string AdminName { get; set; }
    }
}
